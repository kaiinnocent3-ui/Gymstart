const KEY="gymstart_v1";
const defaultState={goal:"muscle",days:3,started:false,logs:[],profile:{}};
let state=JSON.parse(localStorage.getItem(KEY)||"null")||defaultState;
let tab="home";
const plans={
muscle:{name:"Build Muscle",weeks:"8-week beginner plan"},
fat:{name:"Lose Fat",weeks:"8-week beginner plan"},
strength:{name:"Get Stronger",weeks:"8-week beginner plan"},
fitness:{name:"General Fitness",weeks:"8-week beginner plan"}
};
const workouts=[
{name:"Full Body A",ex:[["Goblet Squat",3,10],["Chest Press",3,10],["Lat Pulldown",3,10],["Seated Row",2,12],["Plank",3,30]]},
{name:"Full Body B",ex:[["Leg Press",3,10],["Dumbbell Shoulder Press",3,10],["Cable Row",3,10],["Romanian Deadlift",2,10],["Dead Bug",3,10]]},
{name:"Full Body C",ex:[["Split Squat",3,8],["Incline Chest Press",3,10],["Lat Pulldown",3,10],["Leg Curl",2,12],["Farmer Carry",3,30]]}
];
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function render(){document.getElementById("screen").innerHTML=views[tab](); if(tab==="workout")bindWorkout()}
const views={
home:()=>`<div class="hero"><h2>Welcome${state.profile.name?" "+state.profile.name:""} 👋</h2><p>Your next workout is ready. No guessing, just follow the steps.</p><button class="btn" onclick="tab='workout';render()">Start today's workout</button></div>
<div class="card"><span class="pill">${plans[state.goal].name}</span><h2>${workouts[state.logs.length%3].name}</h2><p class="muted">About 40–50 minutes · Beginner friendly</p></div>
<div class="grid"><div class="card"><b>${state.logs.length}</b><div class="muted">Workouts logged</div></div><div class="card"><b>${state.days}</b><div class="muted">Days / week</div></div></div>`,
programme:()=>`<h2>Your Programme</h2><div class="card"><span class="pill">${plans[state.goal].weeks}</span><h2>${plans[state.goal].name}</h2><p>Train ${state.days} days per week. Start light, learn the movements and gradually add reps or weight.</p></div>${workouts.map((w,i)=>`<div class="card"><h3>Day ${i+1}: ${w.name}</h3><p class="muted">${w.ex.length} exercises</p><button class="btn secondary" onclick="tab='workout';render()">View workout</button></div>`).join("")}`,
journal:()=>`<h2>Progress Journal</h2><div class="card"><h3>Workouts completed</h3><h2>${state.logs.length}</h2><p class="muted">Keep showing up. Your history will build here.</p></div>${state.logs.slice().reverse().map(x=>`<div class="card"><b>${x.name}</b><p class="muted">${new Date(x.date).toLocaleDateString()} · ${x.entries.filter(e=>e.done).length} exercises completed</p></div>`).join("")||`<div class="card"><p>No workouts yet. Complete your first session and it will appear here.</p></div>`}`,
profile:()=>`<h2>Set up your profile</h2><div class="card"><label>Name (optional)</label><input id="name" value="${state.profile.name||""}" placeholder="Your name"><label>Main goal</label><select id="goal"><option value="muscle">Build muscle</option><option value="fat">Lose fat</option><option value="strength">Get stronger</option><option value="fitness">General fitness</option></select><label>Days per week</label><select id="days"><option>2</option><option>3</option><option>4</option><option>5</option></select><button class="btn" onclick="saveProfile()">Save profile</button></div><div class="card"><b>Safety note</b><p class="muted">This MVP provides general fitness guidance, not medical advice. If you have an injury, medical condition, or symptoms that could affect exercise, seek appropriate professional advice before training.</p></div>`
};
function bindWorkout(){const w=workouts[state.logs.length%3];document.querySelector("#screen").innerHTML=`
<h2>${w.name}</h2><p class="muted">Complete each exercise at a controlled pace. Choose a weight you can perform with good technique.</p>
${w.ex.map((e,i)=>`<div class="card"><div class="exercise"><div><h3>${e[0]}</h3><span class="pill">${e[1]} × ${e[2]}${e[2]===30?" sec":" reps"}</span></div><input type="checkbox" id="done${i}" style="width:22px;height:22px"></div><div class="row" style="margin-top:12px"><span class="muted">Weight</span><input type="number" id="weight${i}" placeholder="kg"><span class="muted">Notes</span></div></div>`).join("")}
<button class="btn" onclick="finishWorkout()">Finish workout</button><button class="btn secondary" onclick="tab='home';render()">Cancel</button>`}
function finishWorkout(){const w=workouts[state.logs.length%3];const entries=w.ex.map((e,i)=>({exercise:e[0],weight:document.getElementById("weight"+i).value,done:document.getElementById("done"+i).checked}));state.logs.push({name:w.name,date:new Date().toISOString(),entries});save();tab="journal";render()}
function saveProfile(){state.profile.name=document.getElementById("name").value;state.goal=document.getElementById("goal").value;state.days=+document.getElementById("days").value;save();tab="home";render()}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render()});
document.getElementById("goal")?.addEventListener("change",()=>{});
render();
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
